package com.example.healthcalculator

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.pow

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val editAge = findViewById<EditText>(R.id.editAge)
        val editSex = findViewById<EditText>(R.id.editSex)
        val editHeight = findViewById<EditText>(R.id.editHeight)
        val editWeight = findViewById<EditText>(R.id.editWeight)
        val editSleep = findViewById<EditText>(R.id.editSleep)
        val editMeals = findViewById<EditText>(R.id.editMeals)
        val calculateButton = findViewById<Button>(R.id.calculateButton)
        val clearButton = findViewById<Button>(R.id.clearButton)
        val resultText = findViewById<TextView>(R.id.resultText)

        calculateButton.setOnClickListener {
            // Validar entradas
            val age = editAge.text.toString().toIntOrNull()
            val sex = editSex.text.toString().trim().uppercase()
            val heightCm = editHeight.text.toString().toDoubleOrNull()
            val weight = editWeight.text.toString().toDoubleOrNull()
            val sleepHours = editSleep.text.toString().toDoubleOrNull()
            val meals = editMeals.text.toString().toIntOrNull()

            if (age == null || sex.isEmpty() || heightCm == null || weight == null || sleepHours == null || meals == null) {
                resultText.text = "Por favor, preencha todos os campos corretamente (use M ou F para sexo)."
                return@setOnClickListener
            }
            if (sex != "M" && sex != "F") {
                resultText.text = "Sexo deve ser M (Masculino) ou F (Feminino)."
                return@setOnClickListener
            }

            // Converter altura para metros
            val heightM = heightCm / 100.0

            // Calcular IMC com nova classificação
            val bmi = weight / heightM.pow(2)
            val bmiClassification = when {
                bmi < 18.5 -> "Abaixo do Peso"
                bmi <= 24.9 -> "Peso Ideal"
                bmi <= 29.9 -> "Sobrepeso"
                bmi <= 34.9 -> "Obesidade Grau I"
                bmi <= 39.9 -> "Obesidade Grau II"
                else -> "Obesidade Grau III"
            }

            // Calcular GEB (Harris-Benedict)
            val geb = when (sex) {
                "M" -> 66 + (13.7 * weight) + (5 * heightCm) - (6.8 * age)
                "F" -> 655 + (9.6 * weight) + (1.8 * heightCm) - (4.7 * age)
                else -> 0.0
            }
            // Fator de atividade física (moderado = 1.55)
            val get = geb * 1.55
            // Calorias para perder peso (redução de 500 kcal)
            val caloriesToLoseWeight = get - 500

            // Estimar nível de cortisol (baseado em sono)
            val cortisolEstimate = when {
                sleepHours < 6 -> "Alto (sono insuficiente pode elevar cortisol)"
                sleepHours <= 8 -> "Normal (sono adequado)"
                else -> "Baixo (sono excessivo pode indicar desequilíbrios)"
            }

            // Cálculos de suplementos e água
            val creatineMin = weight * 0.03 // Quantidade mínima de creatina (g/dia)
            val creatineMax = weight * 0.07 // Quantidade máxima de creatina (g/dia)
            // Whey Protein recalculado com base em refeições
            val totalProteinNeed = when {
                sleepHours < 6 || bmi > 30 -> weight * 0.8 // Sedentário
                else -> weight * 1.3 // Atividade moderada
            } // g/dia
            val proteinPerMeal = totalProteinNeed / meals // g/refeição
            val wheyPortions = (totalProteinNeed - (proteinPerMeal * meals * 0.5)) / 25 // Estimativa simples, assumindo 50% da proteína da dieta e 25g por porção de whey
            val wheyRecommendation = if (wheyPortions > 0) "${String.format("%.0f", wheyPortions)} porções/dia (25g cada)" else "0 porções/dia"
            val b12 = when (age) {
                in 0..6 -> 0.4
                in 7..12 -> 0.5
                in 13..36 -> 0.9
                in 37..96 -> 1.2
                in 97..156 -> 1.8
                in 157..Int.MAX_VALUE -> 2.4
                else -> 2.4
            } // mcg/dia
            val water = when {
                age <= 17 -> weight * 40
                age <= 64 -> weight * 35
                else -> weight * 27.5 // Média entre 25 e 30 para idosos
            } / 1000.0 // Litros/dia

            // Cálculo da Vitamina D
            var vitaminD = when {
                age in 1..18 -> 700.0 // Média entre 400 e 1.000 UI para crianças e adolescentes
                age in 19..70 -> 600.0 // Base para adultos
                age > 70 -> 1400.0 // Média entre 800 e 2.000 UI para idosos
                else -> 600.0 // Default para idade inválida
            }
            // Ajuste para gestantes/lactantes e grupos de risco
            if (sex == "F" && age in 15..45) {
                vitaminD = if (bmi > 30) 1000.0 else 600.0 // Gestantes/lactantes com IMC > 30
            } else if (age in 19..70 && bmi > 30) {
                vitaminD = 800.0 // Adultos com obesidade
            }

            // Exibir resultados
            val result = """
                Resultados de Saúde e Suplementação:
                
                IMC: ${String.format("%.2f", bmi)} ($bmiClassification)
                Gasto Energético:
                - GEB (Harris-Benedict): ${String.format("%.0f", geb)} kcal/dia
                - GET (moderadamente ativo, fator 1.55): ${String.format("%.0f", get)} kcal/dia
                - Calorias para Perder Peso: ${String.format("%.0f", caloriesToLoseWeight)} kcal/dia
                Estimativa de Cortisol: $cortisolEstimate
                
                Recomendações de Suplementos e Hidratação:
                - Creatina diária:
                  - Mínima: ${String.format("%.2f", creatineMin)} g
                  - Máxima: ${String.format("%.2f", creatineMax)} g
                - Whey Protein: $wheyRecommendation
                - Vitamina B12: ${String.format("%.1f", b12)} mcg/dia
                - Vitamina D: ${String.format("%.0f", vitaminD)} UI/dia
                - Água: ${String.format("%.2f", water)} L/dia
                - Ômega-3: 1-2 g/dia (dose geral para saúde)
                
                *Nota: Consulte um nutricionista para ajustes personalizados.
            """.trimIndent()

            resultText.text = result
        }

        // Lógica para o botão Limpar Dados
        clearButton.setOnClickListener {
            editAge.text.clear()
            editSex.text.clear()
            editHeight.text.clear()
            editWeight.text.clear()
            editSleep.text.clear()
            editMeals.text.clear()
            resultText.text = "Resultados aparecerão aqui"
        }
    }
}